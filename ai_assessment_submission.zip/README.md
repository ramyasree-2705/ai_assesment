
AI Agent-Based Assessment

How to Run:
1. Install Python
2. pip install streamlit
3. streamlit run app.py

This project contains:
- Generator Agent: creates educational content
- Reviewer Agent: checks content quality
- Streamlit UI: shows agent workflow
