
import streamlit as st

class GeneratorAgent:
    def generate(self, grade, topic, feedback=None):
        explanation = (
            "An angle is made when two lines meet. "
            "A right angle looks like the corner of a book. "
            "An acute angle is smaller than a right angle. "
            "An obtuse angle is bigger than a right angle."
        )

        mcqs = [
            {
                "question": "Which angle is exactly 90 degrees?",
                "options": ["Acute", "Right", "Obtuse", "Straight"],
                "answer": "Right"
            },
            {
                "question": "Which angle is smaller than a right angle?",
                "options": ["Obtuse", "Straight", "Acute", "Reflex"],
                "answer": "Acute"
            }
        ]

        return {
            "explanation": explanation,
            "mcqs": mcqs
        }

class ReviewerAgent:
    def review(self, content):
        feedback = []
        if len(content["explanation"].split()) > 60:
            feedback.append("Explanation is too long for Grade 4")
        status = "pass" if not feedback else "fail"
        return {
            "status": status,
            "feedback": feedback
        }

st.title("AI Agent-Based Educational Content Generator")

grade = st.number_input("Grade", min_value=1, max_value=10, value=4)
topic = st.text_input("Topic", value="Types of angles")

if st.button("Generate Content"):
    generator = GeneratorAgent()
    reviewer = ReviewerAgent()

    content = generator.generate(grade, topic)
    review = reviewer.review(content)

    st.subheader("Generator Output")
    st.json(content)

    st.subheader("Reviewer Feedback")
    st.json(review)
